<?php
/*
Plugin Name: Ultra Stealth Login
Description: Hide wp-login and wp-admin from unauthorized access. Only allow login via a secret URL. Clean, secure, and lightweight.
Version: 2.0
Author: DevShubho
*/

defined('ABSPATH') || exit;

define('USL_DEFAULT_SLUG', 'my-secret-login');

// 🔐 Core logic
add_action('init', function () {
    $secret_slug = sanitize_text_field(get_option('usl_secret_login_slug', USL_DEFAULT_SLUG));
    $request_uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    $method = strtolower($_SERVER['REQUEST_METHOD']);
    $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
    $allowed_actions = ['post', 'logout', 'lostpassword', 'rp', 'resetpass', 'login'];

    // Allow access via secret slug
    if ($request_uri === $secret_slug) {
        require_once ABSPATH . 'wp-login.php';
        exit;
    }

    // Block wp-login.php directly unless specific allowed actions
    if (
        strpos($request_uri, 'wp-login.php') !== false &&
        $request_uri !== $secret_slug &&
        $method !== 'post' &&
        !in_array($action, $allowed_actions, true)
    ) {
        usl_show_generic_error();
    }

    // Block wp-admin if not logged in
    if (
        strpos($request_uri, 'wp-admin') !== false &&
        !is_user_logged_in()
    ) {
        usl_show_generic_error();
    }
});

// ❌ Generic error page
function usl_show_generic_error() {
    status_header(404);
    nocache_headers();
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>404 Not Found</title>
        <style>
            body { background: #f5f5f5; font-family: Arial, sans-serif; color: #222; display: flex; align-items: center; justify-content: center; height: 100vh; flex-direction: column; text-align: center; }
            h1 { font-size: 48px; margin: 0; color: #cc0000; }
            p { font-size: 18px; margin-top: 10px; color: #555; }
        </style>
    </head>
    <body>
        <h1>Error 404</h1>
        <p>The page you are looking for does not exist.</p>
    </body>
    </html>
    <?php
    exit;
}

// ⚙️ Register plugin settings
add_action('admin_init', function () {
    register_setting('usl_settings_group', 'usl_secret_login_slug', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_title',
        'default' => USL_DEFAULT_SLUG
    ]);
});

// 🛠️ Settings menu
add_action('admin_menu', function () {
    add_options_page('Ultra Stealth Login', 'Stealth Login', 'manage_options', 'usl-settings', 'usl_render_settings_page');
});

// 🖥️ Settings page UI
function usl_render_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('Unauthorized access', 'usl'));
    }

    $slug = esc_attr(get_option('usl_secret_login_slug', USL_DEFAULT_SLUG));
    $url = esc_url(home_url('/' . $slug));
    ?>
    <div class="wrap">
        <h1>Ultra Stealth Login Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('usl_settings_group');
            do_settings_sections('usl_settings_group');
            ?>
            <table class="form-table">
                <tr>
                    <th><label for="usl_secret_login_slug">Set Your Secret Login URL</label></th>
                    <td>
                        <input type="text" name="usl_secret_login_slug" id="usl_secret_login_slug" value="<?php echo $slug; ?>" class="regular-text" />
                        <div style="margin-top:8px;font-size:14px;color:#2e7d32;display:flex;align-items:center;gap:10px;">
                            <span style="height:10px;width:10px;background:#4caf50;border-radius:50%;display:inline-block;"></span>
                            <span>
                                Login URL: <code id="usl-secret-url"><?php echo $url; ?></code>
                            </span>
                            <button type="button" class="button button-secondary" onclick="uslCopyToClipboard()">Copy</button>
                        </div>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>

        <script>
        function uslCopyToClipboard() {
            try {
                const text = document.getElementById('usl-secret-url').innerText;
                navigator.clipboard.writeText(text).then(() => {
                    alert('🔗 Secret login URL copied!');
                }, () => {
                    alert('❌ Copy failed.');
                });
            } catch (e) {
                alert('⚠️ Clipboard not supported.');
            }
        }
        </script>

        <hr>
        <p style="font-size:13px;color:#888;">
            🔒 Built with ❤️ by 
            <a href="https://instagram.com/dev.shubho" target="_blank" rel="noopener noreferrer">DevShubho</a>
        </p>
    </div>
    <?php
}

// 💖 Font Awesome (only on plugin settings page)
add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'settings_page_usl-settings') {
        return;
    }
    wp_enqueue_style('usl-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css', [], null);
});
